export interface UserModel{
    name:string,
    age:number,
    favoriteColor:string
}