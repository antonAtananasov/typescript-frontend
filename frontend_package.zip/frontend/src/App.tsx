import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  const [inputName, setInputName] = useState('')
  const [inputAge, setInputAge] = useState('')

  const [users, setUsers] = useState([
    { name: "Anton", age: 16 },
    { name: "Beton", age: 53 },
    { name: "Toncho", age: 22 },
    { name: "Qwerty", age: 32 },
    { name: "Asdf", age: 45 }
  ])

  const createUser = () => {
    const newUser = { name: inputName, age: Number.parseInt(inputAge) }
    // a = [1,2,3]
    // b = 4
    // c = [...a, b, 5] -> [1,2,3,4,5]
    setUsers((users) => {
      const newUsers = [...users, newUser];
      console.log(newUsers);
      return newUsers
    })

    // console.log(users) <- incorrect
  }

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">

        <form>
          {/* <input placeholder='test here' onChange={e => setInputValue(e.target.value)}></input>
          <button onClick={()=>console.log(inputValue)}>Test</button> */}
          <input {...{
            placeholder: "name",
            onChange: (e) => setInputName(e.target.value)
          }}></input>
          <input {...{
            placeholder: "age",
            onChange: (e) => setInputAge(e.target.value)
          }}></input>
          <button {...{
            type: 'button',
            onClick: createUser
          }}>Test</button>
        </form>


        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export default App
